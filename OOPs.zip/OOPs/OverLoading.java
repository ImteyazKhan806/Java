/*
   The argumnet are different & return type is same then achieve
   function overloading.
*/


class OverLoading{
 void show(){
 
 System.out.println("without args" );
 }
 void show(byte x){
 System.out.println("byte x"+x );
 }
 void show(int x){
 System.out.println(" int x " +x);
}
void show(short x){
System.out.println("short x  "+x ); 
}
void show(long x){
System.out.println("long x" +x);
}
void show(double x){
System.out.println("double x" +x);
}
void show(float x){
	System.out.println("float x" +x);
}	
static public  void main(String ...s){
System.out.println("Main Method" );
OverLoading obj =new OverLoading();
obj.show();
obj.show(10);  //int
obj.show((byte)101);
obj.show((short)1055);
obj.show(103797L);     
obj.show(10321.5656); //double
obj.show(145454.4524f);  //float
} 
}