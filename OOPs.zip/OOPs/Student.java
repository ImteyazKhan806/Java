 class Student{
        int id;
		String name;
		String address;
		String coures;
		String subject;
		
		void getData(int i,String n,String addr, String crs,String sub){
		 
		 id = i;
		 name = n;
		 address = addr;
		 coures = crs;
		 subject= sub;
	 }
	 
	 void show(){
		
		 System.out.println("Name = " +name);
		 System.out.println("Id = " +id);
		 System.out.println("Address = " +address);
         System.out.println("Coures = " +coures);
         System.out.println("subject = " +subject);	 
	 }
	 
	    public static void main(String [] args){
	 
	     System.out.println("Start in main :");
         Student  s1= null;      //The null value initialized by programmer/var declaration of the reference var.
         System.out.println("The value of s1 reference  variables " +s1);
         s1 = new Student();
         System.out.println("The reference of id reference variables " +s1);
		 s1.show();
		 s1.getData(123,"Imteyaz Khan","Noida","Java FullStack","Java,HTML,CSS,JavaScripts,DBMS");
		 s1.show();
		 
		  Student s2 = new Student();
          System.out.println("The reference of id reference variables " +s2);
		 
		 s2.getData(234,"Ayaan Khan","Noida","Python FullStack","Python,HTML,CSS,JavaScripts,DBMS");
		 s2.show();
		 
		  Student s3 = new Student();
         System.out.println("The reference of id reference variables " +s3);
		
		 s3.getData(345,"Rehan Khan","Noida","MERN FullStack","Reacj Js,HTML,CSS,JavaScripts,DBMS");
		 s3.show();
		 
		 System.out.println("After initialized  vlaue of data memeber on each object");
		 s1.show();
		 s2.show();
		 s3.show();
		 
		 s2.getData(456,"Sameer Khan","Noida","PHP Fullstack", "PHP,HTML,CSS,JavaScripts,DBMS");
		  System.out.println("After update initialized value of data member on each object");
		 
		 s1.show();
		 s2.show();
         s3.show();

        System.out.println("End of main");		 
	 }
		
}