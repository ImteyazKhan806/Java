/*
  Data shadowing = whenever class variable & local variable are same then 
  this concept is known as data shadowing .
  
  The data shadowing problem solve with help of "this" keywords'
 */



public class Temp4 {
 // Need for this keywords.
 
 
	int x =10;
	void show (int y) {
		int z = 30;
	
		System.out.println("show the ref. id this :"+this);
		System.out.println("class level var. x    :"+this.x);
		System.out.println("local var. args y     :"+y);
		System.out.println("local var function z  :"+z);
	}
	void get(int x) {
		System.out.println("get the ref. id this "+this);
		this.x = x;
	}
	public static void main(String []args) {
	System.out.println("Ex1........");
	Temp4 obj = new Temp4();
	System.out.println("The ref. id obj :"+obj);
	System.out.println("class level var. x main :"+obj.x);
	obj.show(20);
	
	
	Temp4 obj1 = new Temp4();
	System.out.println("\n\n The ref. id obj1 :"+obj1);
	System.out.println("class level var x main :"+obj1.x);
	obj1.show(60);
	
	System.out.println("\n\n Update the value of Data Memeber :");
	
	obj.get(1001);
	obj1.get(2001);
	
	obj.show(89);
	obj1.show(90);
			
  }
	

}