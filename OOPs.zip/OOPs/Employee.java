class Employee{

int id;
String name;
String address;
float salary;
void getData(int i, String n, String addr, float sal){

 id =i;
 name = n;
 address = addr;
 salary = sal;
 }
 void show (){
 System.out.println("Name :        "+name);
   System.out.println("id  :         "+id);
   System.out.println("Address : "+address);
  System.out.println("Salary   :  "+salary);
 }
 public static void main(String ...s){
 System.out.println("Star in main ");
  
  Employee e1= null;     //The null value initialized by programmer/var declaration of the reference var.
  System.out.println("The value of e1 ref. var. "+e1);
  e1 = new Employee();
  System.out.println("The ref. id of e1 ref. var. "+e1);
  e1.show();
  e1.getData(101, "Gopal", "Noida", 25000);
  e1.show();
  
  Employee e2 = new Employee();
  System.out.println("The ref. of id e2 ref. var. "+e2);
  e2.show();
  e2.getData(201,"Anand", "Noida", 40000);
  e2.show();
  
   Employee e3 = new Employee();
  System.out.println("The ref. of id e3 ref. var. "+e3);
  e3.show();
  e3.getData(301,"Ajit", "kanpur", 45000);
  e3.show();
  
  System.out.println("After initialized value of data member on each object");
  e1.show();
  e2.show();
  e3.show();
  
  e1.getData(501,"Amit", "delhi", 30000);
   System.out.println("After update initialized value of data member on each object");
   e1.show();
   e2.show();
   e3.show();
   
   e2=  new Employee();
    System.out.println("The current value of ref.var. (After member on each object");
  e2.getData(505,"Bikash","Delhi",50000);
  e2.show();
 
  System.out.println("End in main ");
}
}