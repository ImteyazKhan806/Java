public class Temp5 {
	
// need to "this" keywords.
	
	int  x =10;


	void show(int y, Temp5 t1) {
		
		int x =30;
	System.out.println("The ref. id t1        :"+t1);
	System.out.println("Class level var x     :"+t1.x);
	System.out.println("Local var args y      :"+y);
	System.out.println("Local var function z x:"+x);
	System.out.println("The ref. id this      :"+this);
	
	}
	public static void main(String []args) {
		System.out.println("Ex1..........");
		Temp5 obj = new Temp5();
		System.out.println("The Ref. id obj         :"+obj);
		System.out.println("Class level var. x main :"+obj.x);
		
		obj.show(20, obj);
		
		Temp5 obj1 = new Temp5();
		System.out.println("\n\n The ref. id obj1  :"+obj1);
		System.out.println("Class level var x main :"+obj1.x);
		
		obj1.show(60, obj1);
	}
	
}
/*
   10  10  30
   20  20  20
   30  10  30 */

