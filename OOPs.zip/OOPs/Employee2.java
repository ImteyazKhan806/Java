class Employee2{
     
	 int id;
	 String name;
	 String address;
	 float  salary = 200.22f;
	 
	 static String company = "TCS";
	 void getData(int i, String n, String addr, float sal){     // this is a local variable
                    id = i;
					name = n;
					address = addr;
					salary = sal;
		}
         void show() {
		 
		 System.out.println(" Name =" +name);
		 System.out.println("Id  = " +id);
		 System.out.println("Address =" +address);
		 System.out.println("Salary = " +salary);
		 System.out.println("Company = " +company);
		 
		 }
		 public static void main(String...s){
		 System.out.println("Start in main");
		 System.out.println("Company = " +company);
		 
		   // System.out.println("Name = " +cname);
		   
		   Employee2 e1 = new Employee2();
		   System.out.println("The Reference id of e1 Reference variable " +e1);
		   e1.getData(101, "Imteyaz","Noida", 25000);
		   e1.show();
		  // System.out.println("Company main e1 = " +e1.company);
		  // System.out.println("Company = " +company);
		   
		   Employee2 e2 = new Employee2();
		   System.out.println("The Reference id of e2 Reference variable " +e2);
		   e2.getData(102, "Ayaan","Noida", 20000);
		   e2.show();
		   
		   Employee2 e3 = new Employee2();
		   System.out.println("The Reference id of e3 Reference variable " +e3);
		   e3.getData(103, "Rehan","Noida", 30000);
		   e3.show();
		   
		   System.out.println("After initializaation value of data member on each object ");
		   e1.show();
		   e2.show();
		   e3.show();
		   
		   // company = "IBM";
		   
		   e3.company = "HCL";
		   System.out.println("After changed company name");
		   e1.show();
		   e2.show();
		   e3.show();
		   
		   
		    e2.getData(104, "Sameer","Noida", 35000);
		   System.out.println("After update value of data member on e2 object  " );
		   e1.show();
		   e2.show();
		   e3.show();
		   
		   System.out.println("End of main");
		 
		   
		   
		 }
		 
  }
