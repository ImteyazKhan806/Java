
/*
   The return are different & arguments are  same then achieve
   function overloading   or not.
*/


class OverLoading1{
 void show(){
 
 System.out.println("without args" );
 }
 void show(int x){
 System.out.println("byte x"+x );          //int =x is already define by and this program is error.  
 }
 void show(int x){
 System.out.println(" int x " +x);
 return 100+x;
}
static public void main (String ...s){
	System.out.println(" main Method");
	OverLoading1 obj = new OverLoading1();
	obj.show(10);
	
}
}