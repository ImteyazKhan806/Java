public class overLoading2 {
	
	int show (char ch, int x, byte y, float z){
		System.out.print("ch = "+ch);
		System.out.print("\tx = "+x);
		System.out.print("\ty = "+y);
		System.out.println("\tz = "+z);
		
		return (int)ch + x+ (int)y+(int)z;
	}
	void  show(char ch ,double a,int x, long y, float z) {
		System.out.print("ch = "+ch);
		System.out.print("\tx = "+x);
		System.out.print("\ty = "+y);
		System.out.println("\tz = "+z);
		
		
	}
	double show(char ch ,int x, short y, float z, double d) {
		System.out.print("ch = "+ch);
		System.out.print("\tx = "+x);
		System.out.print("\ty = "+y);
		System.out.println("\tz = "+z);
		
		return x+y+z+d;
		
		
	}
	public static void main(String []args) {
		System.out.println("\nex. of Overloading -3");
		
		overLoading2 obj = new overLoading2();
		int intreturn = obj.show('A',101,(byte)127,87878.788f);
		System.out.println("The int retured value is "+intreturn);
		
		obj.show('A',6776.7878,101,127L,77878.767f);
		
		double doublereturn = obj.show('A',6776,(short)7887,101.127f,87878.878);
		System.out.println("The double retured value is "+doublereturn);
}


}
