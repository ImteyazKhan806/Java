package myserver;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServer {

	DataInputStream dis;
	DataOutputStream dos;
	ServerSocket ss;
	Socket s;
	public MyServer() {
		
		try {
			ss = new ServerSocket(10);
			System.out.println("Server is Started :");
			s = ss.accept();
			System.out.println("The client is Accepted :");
			dis = new DataInputStream(s.getInputStream());
			dos = new DataOutputStream(s.getOutputStream());
			serverChat();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void serverChat() {
		String s1 =" ";
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			do {
				String s2 = dis.readUTF();
				System.out.println("Server side " +s2);
				
				
				System.out.println("Message input : ");
				s1 = br.readLine();
				dos.writeUTF("Server :"+s1);
						
			}
			while(!s1.equalsIgnoreCase("stop"));
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
            new MyServer();
		
		

	}

}
