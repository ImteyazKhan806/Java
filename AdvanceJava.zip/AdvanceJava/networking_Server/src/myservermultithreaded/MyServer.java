//this project connected to the AdvanceJavaDemo name project in NetworkingClient

package myservermultithreaded;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;


class MyThread  implements  Runnable{

	  Socket s;
	  ArrayList<Socket> al;
	  
	public MyThread(Socket s, ArrayList<Socket> al) {
		super();
		this.s = s;
		this.al = al;
	}

	@Override
	public void run() {
	 String s1 =" ";
	 
	 try {
		
		 DataInputStream dis = new DataInputStream(s.getInputStream());
		 do {
			 s1 = dis.readUTF();
			 if(!s1.equalsIgnoreCase("stop")) {
				 tellEveryOne(s1);
			 }
			 else {
				 DataOutputStream dos = new DataOutputStream(s.getOutputStream());
				 dos.writeUTF(s1);
			 }
				 
		 } while(!s1.equalsIgnoreCase("stop"));
	} catch (Exception e) {
		 e.printStackTrace();
	}
		
	}
	
	public void tellEveryOne(String s1) {
		try {
			Iterator<Socket> itr = al.iterator();
			while(itr.hasNext()) {
				Socket sc = (Socket)itr.next();
				DataOutputStream dos = new DataOutputStream(sc.getOutputStream());
				dos.writeUTF(s1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}

public class MyServer {

	
	 ArrayList<Socket> al = new ArrayList<Socket>();
	 ServerSocket ss;
	 
	 public MyServer() {
		try {
			ss = new ServerSocket(10);
			System.out.println("Server is started :");
			while(true){
				Socket s = ss.accept();
				al.add(s);
				MyThread m1 = new MyThread(s, al);
				Thread t1= new Thread(m1);
				t1.start();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	 
	public static void main(String[] args) {
		
		new MyServer();
	}

}
