package evant_25;

import java.awt.*;

import java.awt.event.*;


public class EventDemo1 implements ActionListener {
	Frame f;
	Label l;
	TextField tf;
	Button b1;
	Button b2;

	public EventDemo1(String str) {
		f = new Frame(str);
		l = new Label("Enter a name");
		l.setBounds(40, 40, 80, 50);

		tf = new TextField();
		tf.setBounds(140, 40, 200, 50);

		b1 = new Button("Ok");
		b1.setBounds(130, 110, 70, 50);

		b2 = new Button("Cancel");
		b2.setBounds(210, 110, 70, 50);

		f.add(l);
		f.add(tf);
		f.add(b1);
		f.add(b2);
		
		//Step1
		//b1.addActionListener(this);
		//b2.addActionListener(this);
		
		Outer o = new Outer(this);
		
		//step2
		//b1.addActionListener(o);
		//b2.addActionListener(o);
		
		//step3
		//b1.addActionListener(this);
	   // b2.addActionListener(o);
		
	  //step4
	  		b1.addActionListener(this);
	  		b2.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					tf.setText("Anonymous class b2");
				}
			});
	  		
	  		ActionListener act = (e->tf.setText("Lamda expp. function "));
	  		b1.addActionListener(act);
	  		
		    f.addWindowListener(new WindowExit());
		    f.setSize(400, 400);
		    f.setLayout(null);
		    f.setVisible(true);
	}
     @Override
    public void actionPerformed(ActionEvent e) {
    	System.out.println("ActionPerformed "+this);
    	if(e.getSource() == b1)
    		tf.setText("Hello from Ok Button");
    	
    	if(e.getActionCommand().equalsIgnoreCase("Cancel"))
    		tf.setText("Demo event class 2");
    	
    }
     
	public static void main(String[] args) {
		new EventDemo1("EventDemo......");
	}
}
	class WindowExit extends WindowAdapter{
		
		 @Override
		public void windowClosing(WindowEvent e) {
			System.exit(1);
		}
		 }
	
	class Outer implements ActionListener{
           
		EventDemo1 demo;
		public Outer(EventDemo1 eventDemo1) {
			this.demo = eventDemo1;
			System.out.println("Demo  "+eventDemo1);
			System.out.println("Outer this "+this);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(e.getSource()==demo.b1);
			demo.tf.setText("Outer class from b1");
			
			if(e.getSource()==demo.b2);
			demo.tf.setText("Outer Class from b2");
			
		}
		
	}

		   
	
	

//Marker Interface ->The interface have no Data member no method is Called ExitListener Marker Interface.
//The  Abstract Class no data member  and no method is called Adapter.