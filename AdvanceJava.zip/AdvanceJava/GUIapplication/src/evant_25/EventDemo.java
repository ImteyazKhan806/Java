package evant_25;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class EventDemo implements ActionListener {
	Frame f;
	Label l;
	TextField tf;
	Button b1;
	Button b2;

	public EventDemo(String str) {
		f = new Frame(str);
		l = new Label("Enter a name");
		l.setBounds(40, 40, 80, 50);

		tf = new TextField();
		tf.setBounds(140, 40, 200, 50);

		b1 = new Button("Ok");
		b1.setBounds(130, 110, 70, 50);

		b2 = new Button("Cancel");
		b2.setBounds(210, 110, 70, 50);

		f.add(l);
		f.add(tf);
		f.add(b1);
		f.add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
		f.addWindowListener(new ExitListener());
		f.setSize(400, 400);
		f.setLayout(null);
		f.setVisible(true);
	}
     @Override
    public void actionPerformed(ActionEvent event) {
    	System.out.println("ActionPerformed "+this);
    	if(event.getSource() == b1)
    		tf.setText("Hello from Ok Button");
    	
    	if(event.getSource() == b2)
    		tf.setText("Good morning from Cancle Button");
    	
    }
     
	public static void main(String[] args) {
		new EventDemo("EventDemo......");
	}
}
	class ExitListener extends WindowAdapter{
		 public void windowClosing(WindowEvent e) {  //Invoked when a window has been closed.
			 System.out.println("Closing......");
			 System.exit(1);
		 }

		   
	}
	

//Marker Interface ->The interface have no Data member no method is Called ExitListener Marker Interface.
//The  Abstract Class no data member  and no method is called Adapter.