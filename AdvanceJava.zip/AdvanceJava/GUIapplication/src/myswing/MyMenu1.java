package myswing;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class MyMenu1  extends MouseAdapter {

	 JFrame f = new JFrame();
	 JPopupMenu pm = new JPopupMenu("Pop");
	 JMenuItem m = new JMenuItem("New");
	 JMenuItem m1 = new JMenuItem("Open");
	 JMenuItem m2 = new JMenuItem("Save");
	 JMenuItem m3 = new JMenuItem("Exit");
	 
	 MyMenu1(){
		pm.add(m);
		pm.add(m1);
		pm.add(m2);
		pm.add(m3);
		
		f.addMouseListener(this);
		f.setSize(400,400);
		f.setVisible(true);
	 }
	 public void mouseClicked(MouseEvent e) {
		int x= e.getButton();
		if(x==MouseEvent.BUTTON3)
			pm.show(e.getComponent(),e.getX(),e.getY());
	 }
	 
	public static void main(String[] args) {
		 new MyMenu1();

	}

}
