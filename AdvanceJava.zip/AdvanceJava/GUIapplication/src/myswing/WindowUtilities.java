package myswing;

import java.awt.Container;

import javax.swing.*;
public class WindowUtilities {
	public static void setNariveLookFeel() {
		
		try {
			 UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			
		} catch (Exception e) {
			System.out.println("Error setting native LAF :" +e);
		}
	}
     public static void setJavaLookAndFeel() {
    	 try {
			 UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Error setting Java LAF :" +e);		}
     }
     public static void setMotifLookAndFeel() {
    	 try {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch (Exception e) {
			System.out.println("Error setting Motif LAF :"+e);
		}
     }
   
    	 
     
	public static void main(String[] args) {
		
	}
	public static void setNativeLookAndFeel() {
		// TODO Auto-generated method stub
		
	}

}