package myswing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class MyMenu implements ActionListener {
	
	JTextField tf = new JTextField();
	JFrame     jf = new JFrame("MyMenu");
	JMenuBar menuBar;
	JMenu menu, submenu;
	JMenuItem menuItem, exit;
	JRadioButtonMenuItem rbMenuItem;
	JCheckBoxMenuItem cbMenuItem;
	
   MyMenu(){
	  jf.add(tf);
	   menuBar = new JMenuBar();
	   menu    = new JMenu("First Menu");
	   menu.setMnemonic(KeyEvent.VK_F);
	   menuBar.add(menu);
	   
	   menuItem = new JMenuItem("A text only menu item", KeyEvent.VK_T);
	   menuItem.addActionListener(this);
	   menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_4, ActionEvent.ALT_MASK));

	   
	   menu.add(menuItem);
	   
	   menu.addSeparator();
	   //a group of radio button menu items
	   ButtonGroup group = new ButtonGroup();
	   rbMenuItem = new JRadioButtonMenuItem("A radio button menu item");
	  rbMenuItem.setMnemonic(KeyEvent.VK_R);
	  group.add(rbMenuItem);
	  menu.add(rbMenuItem);
	  
	  rbMenuItem = new JRadioButtonMenuItem("Another one");
	  rbMenuItem.setMnemonic(KeyEvent.VK_O);
	  group.add(rbMenuItem);
	  menu.add(rbMenuItem);
	  menu.addSeparator();
	  
	  //A group of check box menu item
	  cbMenuItem = new JCheckBoxMenuItem("A check box menu item");
	  cbMenuItem.setMnemonic(KeyEvent.VK_C);
	  menu.add(cbMenuItem);
	  
	  cbMenuItem = new JCheckBoxMenuItem("Another one");
	  cbMenuItem.setMnemonic(KeyEvent.VK_H);
	  menu.add(cbMenuItem);
	  menu.addSeparator();
	  
	  //A submenu
	  submenu = new JMenu("A submenu");
	  submenu.setMnemonic(KeyEvent.VK_S);
	  menuItem  = new JMenuItem("An item in the submenu");
	  menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_2,ActionEvent.ALT_MASK));
	  submenu.add(submenu);
	  
	  exit = new JMenuItem("Exit");
	  exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.ALT_MASK));
	  exit.addActionListener(this);
	  menu.add(exit);
	  
	  //Build second menu int the menu bar
	  menu = new JMenu("Another one");
	  menu.setMnemonic(KeyEvent.VK_N);
	  menuBar.add(menu);
	  jf.setJMenuBar(menuBar);
	  jf.setSize(400, 400);
	  jf.setVisible(true);
  }
   @Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(exit));
		System.exit(0);
		
		if(e.getActionCommand().equals("A text-only menu item"))
		{
			tf.setText("Hello");
		}
		
		
	}
	public static void main(String[] args) {
		
		new MyMenu();
	}

}
