package myswing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class FileChooser extends JFrame implements ActionListener {
    JFileChooser jfc;
    public FileChooser() {
    	super("FileChooser");
    	
    	jfc = new JFileChooser("f:\\jdk864");
    	
    	JButton jb = new JButton("ok");
    	jb.addActionListener(this);
    	
    	getContentPane().add(jb);
    	setSize(400,400);
    	setVisible(true);
    }
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		int x = jfc.showOpenDialog(null); //show SaveDailog(null)
		System.out.println(x);
		
		if(x==JFileChooser.APPROVE_OPTION) {
			File f = jfc.getSelectedFile();
			String s = jfc.getName(f);
			System.out.println(s);
		}
		if(x==JFileChooser.CANCEL_OPTION) {
			System.out.println("cancel");
		}
	}
	public static void main(String[] args) {
		new FileChooser();
	}

	

}
