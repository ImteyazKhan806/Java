package myswing;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyFlowLayout {

	 public MyFlowLayout(String str) {
		 JFrame  f = new JFrame(str);
		 JButton b[] = new JButton[5];
		 String x[] = {"North","South","East","West", "Center"};
		 
		 for(int i = 0;  i < b.length; i++) {
			 b[i] = new JButton(x[i]);
			 f.add(b[i]);
		 }
		 f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 
		 f.setSize(400,400);
		// f.setLayout(new FlowLayout());
		 f.setLayout(new FlowLayout(FlowLayout.LEFT));
		 f.setLayout(new FlowLayout(FlowLayout.RIGHT));
		 f.setLayout(new FlowLayout(FlowLayout.CENTER));
		 f.setLayout(new FlowLayout(FlowLayout.CENTER,40,40));
		 f.setVisible(true);
	 }
	   
	public static void main(String[] args) {
		new MyFlowLayout("MyLayout.......");
	}

}
