package myswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class JButtons extends JFrame {

	public JButtons() {
		super("Using JButton");
		WindowUtilities.setNativeLookAndFeel();

		WindowUtilities.setJavaLookAndFeel();

		WindowUtilities.setMotifLookAndFeel();

		addWindowListener(new ExitListener());
		Container content = getContentPane();

		content.setBackground(Color.BLUE);
		content.setLayout(new FlowLayout());

		JButton button1 = new JButton("First");
		content.add(button1);

		JButton button2 = new JButton("Second");
		content.add(button2);

		JButton button3 = new JButton("Third");
		content.add(button3);

		JButton button4 = new JButton("Forth");
		content.add(button4);

		pack();
		setVisible(true);
	}

	public static void main(String[] args) {
		new JButtons();

	}

}
