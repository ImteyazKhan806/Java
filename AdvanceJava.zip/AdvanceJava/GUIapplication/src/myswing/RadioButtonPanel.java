package myswing;

import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class RadioButtonPanel extends JFrame {
	
	public RadioButtonPanel(String labelString, JRadioButton [] radioButtons, ButtonGroup bg) {
       JRadioButton jb [] = new JRadioButton[5];
       
       for(int i = 0; i <jb.length; i++)
    	   jb[i] = new JRadioButton(i+i+" ");
       ButtonGroup buttonGroup = new ButtonGroup();
       
	setLayout (new FlowLayout(FlowLayout.LEFT));
	add(new JLabel(labelString));
	for(int i = 0; i<radioButtons.length; i++) {
		buttonGroup.add(radioButtons[i]);
		  add(radioButtons[i]);
	}
	pack();
	setVisible(true);
}
	public static void main(String[] args) {
	   JRadioButton jb[] = new JRadioButton[5];
	   for(int i = 0; i <jb.length; i++)
		   jb[i] = new JRadioButton(i+i+" ");
	        ButtonGroup bg = new ButtonGroup();
	        new RadioButtonPanel("jb ex", jb,bg);
		   
	}

}
