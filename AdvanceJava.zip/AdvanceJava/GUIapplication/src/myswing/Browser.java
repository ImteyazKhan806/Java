package myswing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class Browser extends JFrame implements HyperlinkListener, ActionListener {

    public static void main(String[] args) {
        if (args.length == 0)
            new Browser("http://gmail.com");
        else
            new Browser(args[0]);
    }

    private JTextField urlField;
    private JEditorPane htmlPane;
    private String initialURL;

    public Browser(String initialURL) {
        this.initialURL = initialURL;
        WindowUtilities.setNativeLookAndFeel();

        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.LIGHT_GRAY);

        JLabel urlLabel = new JLabel("URL:");
        urlField = new JTextField(30);
        urlField.setText(initialURL); // Set the initial URL in the text field
        urlField.addActionListener(this);

        topPanel.add(urlLabel);
        topPanel.add(urlField);
        getContentPane().add(topPanel, BorderLayout.NORTH);

        try {
            htmlPane = new JEditorPane(initialURL);
            htmlPane.setEditable(false);
            htmlPane.addHyperlinkListener(this);

            JScrollPane jScrollPane = new JScrollPane(htmlPane);
            getContentPane().add(jScrollPane, BorderLayout.CENTER);

        } catch (IOException ioe) {
            showError("Can't build HTML pane for " + initialURL + ": " + ioe.getMessage());
        }

        Toolkit t = getToolkit();
        Dimension screensize = t.getScreenSize();
        int width = screensize.width * 8 / 10;
        int height = screensize.height * 8 / 10;
        setBounds(width / 8, height / 8, width, height);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String url = urlField.getText();
        try {
            htmlPane.setPage(new URL(url));
        } catch (IOException ioe) {
            showError("Error loading page: " + ioe.getMessage());
        }
    }

    @Override
    public void hyperlinkUpdate(HyperlinkEvent e) {
        if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
            URL url = e.getURL();
            try {
                htmlPane.setPage(url);
                urlField.setText(url.toString()); // Update the URL field when a link is clicked
            } catch (IOException ioe) {
                showError("Error loading linked page: " + ioe.getMessage());
            }
        }
    }

    // Method to show error messages in a dialog box
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
