package myswing;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BLayout {

	public BLayout(String str) {
		 JFrame  f = new JFrame(str);
		 JButton b[] = new JButton[5];
		 String x[] = {"North","South","East","West", "Center"};
		 String x1[] = {BorderLayout.NORTH,BorderLayout.SOUTH,BorderLayout.EAST,BorderLayout.WEST,BorderLayout.CENTER};
		 
		 for(int i = 0;  i < b.length; i++) {
			 b[i] = new JButton(x[i]);
			 f.add(b[i],x1[i]);
		 }
		 f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 
		 f.setSize(400,400);
		// f.setLayout(null);
		 f.setVisible(true);
	 }
	   
	public static void main(String[] args) {
		new BLayout("BLayout.......");
	}

}
