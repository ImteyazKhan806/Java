package myswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;

public class JColorChooserTest extends JFrame implements ActionListener {

	public static void main(String[] args) {
		new JColorChooserTest();
	}
	public JColorChooserTest() {
		super("Using JColorChooser");
		//WindowUtilities.setNativeLookAndFeel();
		
		WindowUtilities.setJavaLookAndFeel();
		
		//WindowUtilities.setMotifLookAndFeel();
		
		addWindowListener(new ExitListener());
		
		Container content = getContentPane();
		content.setBackground(Color.white);
		content.setLayout(new FlowLayout());
		
		JButton colorButton = new JButton("choose Background color");
		colorButton.addActionListener(this);
		content.add(colorButton);
		setSize(300,100);
		setVisible(true);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		//Args are parent component, title, initial color
		
		Color bgColor = JColorChooser.showDialog(this, "Choose Background Color", getForeground());
		if(bgColor != null)
			getContentPane().setBackground(bgColor);
	}
	

}
