package myswing;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class MyTree {
	JFrame jf;
	JTree jt;
	JScrollPane jp;
	
	public MyTree() {
		jf= new JFrame("Tree demo");
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("style");
		
		DefaultMutableTreeNode color = new DefaultMutableTreeNode("color");
		DefaultMutableTreeNode font = new DefaultMutableTreeNode("font");
		root.add(color);
		root.add(font);
		
		DefaultMutableTreeNode red = new DefaultMutableTreeNode("red");
		DefaultMutableTreeNode green = new DefaultMutableTreeNode("green");
		DefaultMutableTreeNode blue = new DefaultMutableTreeNode("blue");
		color.add(red);
		color.add(green);
		color.add(blue);
		
		DefaultMutableTreeNode bold = new DefaultMutableTreeNode("bold");
		DefaultMutableTreeNode italic = new DefaultMutableTreeNode("italic");
		DefaultMutableTreeNode un = new DefaultMutableTreeNode("un");
		font.add(bold);
		font.add(italic);
		font.add(un);
		
		jt = new JTree(root);
		jp = new JScrollPane(jt);
		jf.add(jp);
		//jf.setSize(60,60); //used to pack method
		jf.pack();
		jf.setVisible(true);
	
	}

	public static void main(String[] args) {
		new MyTree();
	}

}
