package myswing;


import java.awt.FlowLayout;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyPannel {

	public MyPannel(String str) {
		 JFrame  f = new JFrame(str);
		 JButton b1 = new JButton("MyPannel");
		 JPanel p1 = new JPanel();
		 p1.add(b1);
		 
		 //f.add(b1);
		 f.add(p1);
		 
		 f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 
		 f.setSize(400,400);
		 f.setLayout(new FlowLayout());
		 f.setVisible(true);
	 }
	   
	public static void main(String[] args) {
		new MyPannel("MyPannel.......");
	}

}
