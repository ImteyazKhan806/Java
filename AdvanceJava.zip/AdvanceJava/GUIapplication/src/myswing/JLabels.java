package myswing;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JLabels extends JFrame{
	
	public JLabels() {
		super("Using HTML in JLabels");
		WindowUtilities.setNativeLookAndFeel();
		addWindowListener(new ExitListener());
		
		Container content = getContentPane();
		Font font = new Font("Serif", Font.PLAIN, 50);
		content.setFont(font);
		
		String labelText = "<html><FONT COLOR=RED>Red</FONT> and "+
		"<FONT COLOR=BLUE>Blue</FONT> Text</html>";
		
		JLabel coloredLabel = new JLabel(labelText, JLabel.CENTER);
		coloredLabel.setBorder(BorderFactory.createTitledBorder("Mixed Color"));
		content.add(coloredLabel, BorderLayout.NORTH);
		
		labelText = "<html><B>Bold</B> and <I>Italic</I> Text</html>";
		JLabel boldLabel = new JLabel(labelText, JLabel.CENTER);
		boldLabel.setBorder(BorderFactory.createTitledBorder("Mixed Fonts"));
		content.add(boldLabel,BorderLayout.CENTER);
		labelText = "<html>India is a good country" +" in the World"+
		    "<p>"+"Major cities of India"+
				"<UL>"+
		            "<LI>Delhi"+
				    "<LI>Noida"+
		            "<LI>Mombai"+
				    "<LI>Patna"+
		            "<LI>Meerut"+
				    "<LI>Lucknow"+
		            "<LI>Bhopal"+
				    "<LI>etc"+
		             "</UL>";
		   JLabel fancyLabel = new JLabel(labelText,JLabel.CENTER);
		   fancyLabel.setBorder(BorderFactory.createTitledBorder("Multi-Line HTML"));
		   content.add(fancyLabel,BorderLayout.SOUTH);
		   
		   pack();
		   setVisible(true);
		          
	}

	public static void main(String[] args) {
		new JLabels();
	}

}
