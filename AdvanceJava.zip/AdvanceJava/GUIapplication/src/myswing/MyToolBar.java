package myswing;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JToolBar;

public class MyToolBar implements ActionListener {

	TextField t = new TextField();
	JToolBar jt = new JToolBar("my");
	JFrame  jf = new JFrame("myframe");
	JButton jb = new JButton("ok");
	JButton jb1 = new JButton("ok1");
	
	public MyToolBar() {
		Container c =jf.getContentPane();
		jb.addActionListener(this);
		jb1.addActionListener(this);
		jt.add(jb);
		jt.add(jb1);
		
		c.add(t);
		c.add(jt);
		c.setLayout(new FlowLayout(FlowLayout.LEFT));
		jf.setSize(300,300);
		jf.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		  if (e.getSource() == jb) {
	            t.setText("Button 'ok' pressed!");
	        }
	        // Action for jb1 (ok1 button)
	        else if (e.getSource() == jb1) {
	            t.setText("Button 'ok1' pressed!");
	        }
		
	}
	public static void main(String[] args) {
		 new MyToolBar();

	}

	

}
