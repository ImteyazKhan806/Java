package myswing;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class CLayout implements ActionListener {

	CardLayout c1 = new CardLayout();
	JPanel p1 = new JPanel();

	public CLayout(String str) {
		JFrame f = new JFrame(str);
		p1.setLayout(c1); // Panel to cardLayout call
		JButton b[] = new JButton[5];
		String x[] = { "North", "South", "East", "West", "Center" };

		for (int i = 0; i < b.length; i++) {
			b[i] = new JButton(x[i]);
			b[i].addActionListener(this);
			p1.add(b[i]);
		}

		f.add(p1);

		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setSize(400, 400);
		f.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		c1.next(p1); // CardLayout to Panel call

	}

	public static void main(String[] args) {
		new CLayout("CardLayout.......");
	}

}
