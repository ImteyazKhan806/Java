package myswing;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class MyJTable extends JFrame {
      
	String [] headings = {"name" , "addr" , "salary"};
	String items[] []= {
			{"Amit","Delhi","1000"},
			{"Aman","Delhi","2000"},
			{"Arman","Delhi","3000"},
			{"Adil","Delhi","4000"},
			{"Ayaan","Delhi","5000"},
	};
	public MyJTable() {

       super("Table example");
       JTable jt  = new JTable(items,headings);
       JScrollPane jp = new JScrollPane(jt);
       add(jp);
       //setSize(400,400);
       pack();
       setVisible(true);
       
       
	}
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         new MyJTable();
	}

}
