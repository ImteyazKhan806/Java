package myswing;

import java.awt.Button;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class MyJFrame extends JFrame implements ActionListener {
	
	JButton b1;
	Button b2;
	JLabel l1;
	JTextField tf;
	
    public MyJFrame(String str) {
    	super(str);
    	
    	l1 = new JLabel("Exaple of Swing");
    	l1.setBounds(150, 50, 150, 50);
    	Container c1 = getContentPane();
    	
    	b1 = new JButton("Swing");
    	b1.setBounds(100, 120, 150, 50);
    	
    	b2 = new Button("Awt");
    	b2.setBounds(100, 180, 150, 50);
    	
    	tf = new JTextField();
    	tf.setBounds(270, 130, 100, 50);
    	
    	c1.add(l1);
    	c1.add(b1);
    	c1.add(b2);
    	c1.add(tf);
    	
    	b1.addActionListener(this);
    	b2.addActionListener(this);
    	
    	//setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    	setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    	
    	setSize(400,400);
    	setLayout(null);
    	setVisible(true);
    	
    	
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b1)
			tf.setText("Example of Swing");
		
		if(e.getSource() == b2)
			tf.setText("Example of Awt");
		
	}

	public static void main(String[] args) {
		new MyJFrame("MyJframe...............");
	}

}
