package myswing;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MovingBall extends JPanel implements Runnable{


    private int x = 0;        // Ball's x position
    private int y = 100;      // Ball's y position

    // Ball movement thread
    public void run() {
        while (true) {
            x += 5; // move right
            if (x > getWidth()) {
                x = 0; // reset position
            }
            repaint(); // ask Swing to redraw
            try {
                Thread.sleep(50); // pause for animation effect
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Drawing the ball
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.fillOval(x, y, 30, 30); // draw the ball
    }

    // Main method to launch GUI
    public static void main(String[] args) {
        JFrame frame = new JFrame("Moving Ball");
        MovingBall ball = new MovingBall();
        frame.add(ball);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Start the animation thread
        Thread t = new Thread(ball);
        t.start();
    }
}
