package myswing;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JLabels1 extends JFrame{
	
	public JLabels1() {
		super("Using HTML in JLabels");
		WindowUtilities.setNativeLookAndFeel();
		addWindowListener(new ExitListener());
		
		Container content = getContentPane();
		Font font = new Font("Serif", Font.PLAIN, 50);
		content.setFont(font);
		
		String labelText = "<html><FONT COLOR=RED>Red</FONT> and "+
		"<FONT COLOR=BLUE>Blue</FONT> Text</html>";
		
		JLabel coloredLabel = new JLabel(labelText, JLabel.CENTER);
		coloredLabel.setBorder(BorderFactory.createTitledBorder("Mixed Color"));
		content.add(coloredLabel, BorderLayout.NORTH);
		
		labelText = "<html><B>Bold</B> and <I>Italic</I> Text</html>";
		JLabel boldLabel = new JLabel(labelText, JLabel.CENTER);
		boldLabel.setBorder(BorderFactory.createTitledBorder("Mixed Fonts"));
		content.add(boldLabel,BorderLayout.CENTER);
		labelText ="<html>The Applied Physics Laboratory is a division" +" Of the Hopkins University"+
			    "<p>"+" Major JHU divisions include:"+
					"<UL>"+
			            "<LI>The Appkied Physics Laboratory"+
					    "<LI>The Krieger school of Arts and sciences"+
			            "<LI>The Whiting School of Engineering"+
					    "<LI>The School of Medicine"+
			            "<LI>The School of Public Health"+
					    "<LI>The School of Nursing "+
			            "<LI>The Peabody Institute"+
					    "<LI>The Nitze School of Advanced International Studies"+
			             "</UL>";
		   JLabel fancyLabel = new JLabel(labelText,JLabel.CENTER);
		   fancyLabel.setBorder(BorderFactory.createTitledBorder("Multi-Line HTML"));
		   content.add(fancyLabel,BorderLayout.SOUTH);
		   
		   pack();
		   setVisible(true);
		          
	}

	public static void main(String[] args) {
		new JLabels1();
	}

}
