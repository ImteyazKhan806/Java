package myswing;


import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class GLayout {

	public GLayout(String str) {
		 JFrame  f = new JFrame(str);
		 JButton b[] = new JButton[5];
		 String x[] = {"North","South","East","West", "Center"};
		
		 
		 for(int i = 0;  i < b.length; i++) {
			 b[i] = new JButton(x[i]);
			 f.add(b[i]);
		 }
		 f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 
		 f.setSize(400,400);
		 f.setLayout(new GridLayout());
		 f.setLayout(new GridLayout(2,3));
		 
		 f.setVisible(true);
	 }
	   
	public static void main(String[] args) {
		new GLayout("GLayout.......");
	}

}
