package awt_25;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;

public class MyFrame2 {
	Frame f;
	Label l;
	TextField tf;
	Button b1;
	Button b2;

	public MyFrame2(String str) {
		f = new Frame(str);
		l = new Label("Enter a name");
		l.setBounds(40, 40, 80, 50);

		tf = new TextField();
		tf.setBounds(140, 40, 120, 50);

		b1 = new Button("Ok");
		b1.setBounds(130, 110, 70, 50);

		b2 = new Button("Cancel");
		b2.setBounds(210, 110, 70, 50);

		f.add(l);
		f.add(tf);
		f.add(b1);
		f.add(b2);
		f.setSize(400, 400);
		f.setLayout(null);
		f.setVisible(true);
	}

	public static void main(String[] args) {
		new MyFrame2("MyFrame2.........");
	}

}
