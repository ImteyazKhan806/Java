//1>By extending the Frame class (Inheritance)

package awt_25;

import java.awt.Frame;

public class MyFrame extends Frame {
	public MyFrame(String str) {
		super(str);
		setSize(400, 400);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new MyFrame("MyFrame........");
	}

}
