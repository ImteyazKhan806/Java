module GUIapplication {
	
	requires java.desktop;
}
