/*constructor overloading का real-life example लें, तो मान लीजिए कि आप एक Car class बना रहे हैं,
और आपको different types की cars बनाने के लिए अलग-अलग initialization options चाहिए। 
आप चाहेंगे कि कभी-कभी car का नाम और रंग specify किया जाए,
और कभी-कभी default values ही सही हों। */

package mythread;     

public class OverloadingCar {
    private String model;
    private String color;
    private int year;

    // Default constructor
    public OverloadingCar() {
        this.model = "Default Model";
        this.color = "Black";
        this.year = 2020;
    }

    // Parameterized constructor
    public OverloadingCar(String model, String color) {
        this.model = model;
        this.color = color;
        this.year = 2020; // Default year
    }

    // Another parameterized constructor
    public OverloadingCar(String model, String color, int year) {
        this.model = model;
        this.color = color;
        this.year = year;
    }

    public void displayDetails() {
        System.out.println("Car Model: " + model + ", Color: " + color + ", Year: " + year);
    }

    public static void main(String[] args) {
    	OverloadingCar car1 = new OverloadingCar(); // Calls default constructor
    	OverloadingCar car2 = new OverloadingCar("Tesla", "Red"); // Calls constructor with model and color
    	OverloadingCar car3 = new OverloadingCar("BMW", "Blue", 2023); // Calls constructor with model, color, and year

        car1.displayDetails();
        car2.displayDetails();
        car3.displayDetails();
    }
}
