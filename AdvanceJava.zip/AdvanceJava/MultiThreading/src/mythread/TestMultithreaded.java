package mythread;

class CustomThread extends Thread
{
	String tname;
	Thread t;
	public CustomThread() { }
	public CustomThread(String tname) {
		super(tname);
		this.tname = tname;
		start();
	}
	@Override
	public void run() {
		System.out.println("\nStart in run :" +Thread.currentThread().getName());
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+tname);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
           System.out.println("End of run :" +tname);
           
	}
}

class CustomThread1 implements Runnable
{
	String tname;
	Thread t;
	public CustomThread1() { }
	public CustomThread1(String tname) {
		this.tname = tname;
		t = new Thread(this, tname);
		t.start();
	}
	@Override
	public void run() {
		System.out.println("\nStart in run :" +tname);
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+tname);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
           System.out.println("End of run :" +tname);
           
	}
}

class CustomThread2 implements Runnable
{
	String tname;
	Thread t;
	public CustomThread2() { }
	public CustomThread2(String tname) {
		this.tname = tname;
		t = new Thread(this, tname);
		t.start();
	}
	@Override
	public void run() {
		System.out.println("\nStart in run :" +tname);
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+tname);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
           System.out.println("End of run :" +tname);
           
	}
}
class CustomThread3 implements Runnable
{
	String tname;
	Thread t;
	public CustomThread3() { }
	public CustomThread3(String tname) {
		this.tname = tname;
		t = new Thread(this, tname);
		t.start();
	}
	@Override
	public void run() {
		System.out.println("\nStart in run :" +tname);
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+tname);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
           System.out.println("End of run :" +tname);
           
	}
}

public class TestMultithreaded {
	
	public static void main(String[] args) {
		System.out.println("\nstart in "+Thread.currentThread().getName());
		CustomThread obj = new CustomThread("Thread-First");
		CustomThread1 obj1 = new CustomThread1("Thread-Second");
		CustomThread2 obj2 = new CustomThread2("Thread-Third");
		CustomThread3 obj3 = new CustomThread3("Thread-Fourth");
	
		
		System.out.println("Thread-1 is deadth or not " +obj.isAlive());
		System.out.println("Thread-2 is deadth or not " +obj1.t.isAlive());
		System.out.println("Thread-3 is deadth or not " +obj1.t.isAlive());
		System.out.println("Thread-4 is deadth or not " +obj1.t.isAlive());
		
		
		try {
			obj.join();
			obj1.t.join();
			obj2.t.join();
			obj3.t.join();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
			
		}
		System.out.println("Thread-1 is deadth or not " +obj.isAlive());
		System.out.println("Thread-2 is deadth or not " +obj1.t.isAlive());
		System.out.println("Thread-3 is deadth or not " +obj1.t.isAlive());
		System.out.println("Thread-4 is deadth or not " +obj1.t.isAlive());
		System.out.println("Thread-5 is deadth or not " +obj1.t.isAlive());
		
		System.out.println("End of " +Thread.currentThread().getName());

	}

}
