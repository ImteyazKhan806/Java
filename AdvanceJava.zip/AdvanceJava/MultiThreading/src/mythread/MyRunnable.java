package mythread;

public class MyRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println("\nStart in run :" +Thread.currentThread().getName());
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
           System.out.println("End of run :" +Thread.currentThread().getName());
           
	}

	public static void main(String[] args) {
		System.out.println("\nstart in :" +Thread.currentThread().getName());
		
        Runnable r1 = new MyRunnable();
        Thread t1 = new Thread(r1);
        t1.start();
        
        Runnable r2 = new MyRunnable();
        Thread t2   = new Thread(r2);
        t2.start();
        
        Runnable r3 = new MyRunnable();
        Thread t3 = new Thread(r3);
        t3.start();
        
        for(int i = 0; i < 5; i++)
        {
        	System.out.println("i  =" +i+" " +Thread.currentThread().getName());
        	try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        }
        System.out.println("End of " +Thread.currentThread().getName());
	}

}
