package mymain;

public class MyThread extends Thread {
  
	public void run()
	{
		Thread cthread = Thread.currentThread();
		System.out.println("\nstart in Run  :" +cthread.getName());
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+cthread.getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of Run   :" +cthread.getName());
		
	}
	public static void main(String[] args) {
		Thread cthread = Thread.currentThread();
		System.out.println("\nStart in main thread :" +cthread.getName());
		MyThread obj = new MyThread();
		//obj.run(); //can't the child thread
		
		obj.start();
		//obj.start();   //can't start more than one thread
	
		
		MyThread obj1 = new MyThread();
		obj1.start();
		
		MyThread obj2 = new MyThread();
		obj2.start();
		
		MyThread obj3 = new MyThread();
		obj3.start();
		
		for(int i = 0; i < 5; i++)
		{
			System.out.println("i = "+i+" "+cthread.getName());
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of main thread :" +cthread.getName());
	}

}
