package mymain;

public class TestMain {

	public static void main(String[] args) {
	System.out.println("\nMain method===============");	
    Thread t1 = Thread.currentThread();
    String tname = t1.getName();
    System.out.println("Currently running thread :" +tname);
    System.out.println("Currently running thread :" +t1.getName());
    
    t1.setName("Ducat");
    System.out.println("After change main name   :" +t1.getName());
	}

}
