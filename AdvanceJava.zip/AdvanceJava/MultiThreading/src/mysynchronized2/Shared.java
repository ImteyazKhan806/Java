package mysynchronized2;

public class Shared {
     
	static int x;
	 static synchronized public void show(int a, String tname) {  //static Synchronized Method
		 
		x = a;
	  System.out.println("Start in show :"+tname);
		try {
			Thread.sleep(1500);
			System.out.println("x = "+x+" "+tname);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("end of Show :"+tname);
	} 
	static synchronized public void show1(int b, String tname) {     //Non Synchronized Method
			x = b;
			System.out.println("Start in show1 :"+tname);
			try {
				Thread.sleep(1500);
				System.out.println("x = "+x+" "+tname);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("End of Show1 :"+tname);
	}

}
