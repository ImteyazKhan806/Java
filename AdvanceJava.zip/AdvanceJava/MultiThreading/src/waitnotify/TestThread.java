package waitnotify;

class CustomThread extends Thread{
	volatile boolean flag = true;
	public CustomThread(String tname) {
		super(tname);
		start();
	}
    @Override
    public void run() {
    	System.out.println("start in run " +Thread.currentThread().getName());
    	for(int i = 1; i <= 5; i++)
    	{
    		System.out.println("i = "+i+ " "+Thread.currentThread().getName());
    		try {
				Thread.sleep(1500);
				synchronized (this)
				{
					while(!flag) {
						System.out.println("Wait...............");
						wait();
					}
				}
    		}catch(InterruptedException e) {
				   e.printStackTrace();
			   }
    	}
    	
    	System.out.println("End of run "+Thread.currentThread().getName());
    }
    public void mysuspend() {
    	
    	flag = false;
    	System.out.println("suspend................");
    }
	synchronized void myresume() {
		System.out.println("Resume................");
		flag = true;
		notify();
		System.out.println("NOtify..................");
	}
}
public class TestThread {

	public static void main(String[] args) {
		
		System.out.println("\nWait Notify  ");
		CustomThread thread1 =new  CustomThread(" one ");
		CustomThread thread2 =new  CustomThread(" two ");
		
		try {
			Thread.sleep(1000);
			thread1.mysuspend();
			System.out.println("Thread1 is Sleeping progress.........");
			thread1.myresume();
			System.out.println("Thread1 is resume......... ");
			
			thread2.mysuspend();
			System.out.println("Thread2 is Sleeping  progress.......");
			Thread.sleep(1000);
			thread2.myresume();
			System.out.println("Thread2 is resume..........");
			Thread.sleep(1500);
			thread2.myresume();
			System.out.println("Thread2 is resume .....");
			
			thread1.join();
			thread2.join();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
