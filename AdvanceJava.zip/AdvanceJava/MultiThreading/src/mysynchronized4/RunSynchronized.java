package mysynchronized4;

public class RunSynchronized {

	public static void main(String[] args) {
		
		Shared s = new Shared();
		CustomThread1 obj1 = new CustomThread1("One ",s);
		CustomThread2 obj2 = new CustomThread2("Two ",s);
		CustomThread3 obj3 = new CustomThread3("Three ",s);
		

	}

}

//The luck is maintain on object Data is not lost in Synchronized