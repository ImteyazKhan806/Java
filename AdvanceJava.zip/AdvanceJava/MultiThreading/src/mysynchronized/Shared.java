package mysynchronized;

public class Shared {
     
	int x;
	 synchronized public void show(int x, String tname) {  //Non Synchronized Method
		 
		this.x = x;
	  System.out.println("Start in show :"+tname);
		try {
			Thread.sleep(1500);
			System.out.println("x = "+this.x+" "+tname);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("end of Show :"+tname);
	} 
	synchronized public void show1(int x, String tname) {     //Non Synchronized Method
			this.x = x;
			System.out.println("Start in show :"+tname);
			try {
				Thread.sleep(1500);
				System.out.println("x = "+this.x+" "+tname);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("End of Show1 :"+tname);
	}

}
