package mysynchronized;

public class CustomThread1 extends Thread{   //first
    
	Shared d;
	public CustomThread1() {     }
	public CustomThread1(String tname,Shared d) {
		super(tname);
		this.d = d;
		start();
	}
	@Override
	public void run() {
		d.show(10,Thread.currentThread().getName());
		
		
	}
	
}

class CustomThread2 extends Thread{   //second
    
	Shared d;
	public CustomThread2() {     }
	public CustomThread2(String tname,Shared d) {
		super(tname);
		this.d = d;
		start();
	}
	@Override
	public void run() {
		d.show(30,Thread.currentThread().getName());
		
		
	}
	
}

class CustomThread3 extends Thread{   //Third
    
	Shared d;
	public CustomThread3() {     }
	public CustomThread3(String tname,Shared d) {
		super(tname);
		this.d = d;
		start();
	}
	@Override
	public void run() {
		d.show1(20,Thread.currentThread().getName());
		
		
	}
	
}
