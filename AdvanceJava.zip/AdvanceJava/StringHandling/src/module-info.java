/**
 * 
 */
/**
 * 
 */
module mystring {
}