package mystring;

public class TestStringObject {

	public static void main(String[] args) {
		//Write the code here.
		
		System.out.println("\nCreare string object string class by using string literals:");
        String s1 = "Hello";
        String s2 = "Hello";
        System.out.println("S1 = " +s1+"\t s2 ="+s2);
        
        System.out.println("\ns1==s2  =" +(s1==s2));
        System.out.println("\ns1 equals s2 " +s1.equals(s2));
        
        System.out.println("\n By using new Operator");
        
        String sobj = new String("Hello");
        String sobj1 = new String ("Hello");
		System.out.println("sobj ="+sobj+"\tsobj1 = "+sobj1);
		System.out.println("\nsobj equals sobg1 =" +sobj.equals(sobj1));
		
		String sobj2 =new String("Hello").intern(); //method, return the string from the pool
		
		 System.out.println("sobj2 = "+sobj2);
		 System.out.println("\nsobj2==s2  = "+(sobj2==s2)); //sobj2 equals s2 
         System.out.println("\sobj2==s1   = "+(sobj2==s1));  //sobj2 equals s1
	}

}
