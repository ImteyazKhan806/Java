 package mystring;

public class StringConstructor {

	public static void main(String[] args) {
		System.out.println("\nConstructor of string class");
		String sobj = new String();
		System.out.println("sobj ="+sobj);
		
		String sobj1 = new String("Good Morning");
		System.out.println("sobj1 = "+sobj1);
		
		char ch[] = {'I','N','D','I','A'};
		String sobj2 = new String(ch);
		System.out.println("sobj2 ="+sobj2);
		
		String sobj3 = new String(ch,2,3);
		System.out.println("sobj3 ="+sobj3);
		
		byte[]b = {65,66,67,68,69,70};
		String sobj4 = new String(b);
		System.out.println("sobj4 ="+sobj4);
		
		String sobj5 = new String(b,3,3);
		System.out.println("sobj5 ="+sobj5);
		
		int[]i = {65,66,67,68,69,70};
		String sobj6 = new String(i,2,3);
		System.out.println("sobj6 ="+sobj6);
		
		
		
	}

}
