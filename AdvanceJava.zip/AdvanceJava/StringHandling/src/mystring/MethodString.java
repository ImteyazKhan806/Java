package mystring;

public class MethodString {

	public static void main(String[] args) {
		System.out.println("\nMethod of string class :");
		String sobj = new String();
		System.out.println("If string object is blank T/F " + sobj.isBlank());
		System.out.println("If string object is empty T/F " + sobj.isEmpty());

		String s1 = "Welcome";
		System.out.println("If string object is Blank T/F " + s1.isBlank());
		System.out.println("If string object is Empty T/F " + s1.isEmpty());

		int length = s1.length();
		System.out.println("The length of string :" + length);

		System.out.println("The Output of string char. using charAt(index) basic :");
		for (int i = 0; i < s1.length(); i++)
			System.out.println("s1[" + i + "] = " + s1.charAt(i));

		char[] charr = s1.toCharArray();
		System.out.println("The output of string char. by char. using for-each loop :");
		for (char c : charr)
			System.out.print(" " + c);

		System.out.println("\nThe output of String char. by char.using toCharArray() index");
		for (int i = 0; i < charr.length; i++)
			System.out.println("ch[" + i + "] = " + charr[i]);

		String s2 = "ABCDEF";
		byte[] bArr = s2.getBytes();
		System.out.println("The Output of string byte Array getBytes(");
		for (int i = 0; i < bArr.length; i++)
			System.out.println("bArray[" + i + "] = " + bArr[i]);

		System.out.println("\nThe Output of string byte Array getBytes() for each loop");
		for (byte b : bArr)
			System.out.print(" " + b);

		System.out.println("\nTo lower case letter : " + s2.toLowerCase());
		System.out.println("s2 = " + s2);
		s2 = s2.toLowerCase();
		System.out.println("s2 =" + s2);

		System.out.println("\nTo lower case letter :" + s2.toUpperCase());
		System.out.println("s2 =" + s2);

		System.out.println("Ascii code of index 2 = " + s2.codePointAt(2));
		System.out.println("Ascii code of index 2 Before = " + s2.codePointAt(1));

		String s3 = "Abcdfe";
		System.out.println("compareTO Ascii code  : " + s2.compareTo(s3)); // 32
		System.out.println("compareTO Ascii code  : " + s3.compareTo(s2)); // -32

		System.out.println("compareTo ascii code : " + s3.compareToIgnoreCase(s2)); // -32 -1
		System.out.println("Equals  : " + s3.equals(s2)); // True/False value
		System.out.println("Equals  : " + s3.equalsIgnoreCase(s2)); // True/False

		String s4 = "Welcome to India";
		System.out.println("Index of particular string : " + s4.indexOf("c"));
		System.out.println("indexInStart :" + s4.lastIndexOf("c"));
		System.out.print("print the string Repeated minner on the basis of args : \n" + s4.repeat(2)); // s4 variable ka
																										// vulue

		System.out.println("\nstart with string W T/F  : " + s4.startsWith("W"));
		System.out.println("start with string w T/F  : " + s4.startsWith("w"));
		System.out.println("End with string   a T/F  :" + s4.endsWith("a"));
		System.out.println("End with string   A T/F  :" + s4.endsWith("A"));

		String s5 = "India = New Delhi  : Nepal = Kathmandu : pakistan = Islamabadh : ";
		String s6[] = s5.split(":");
		System.out.println("The Output of split string ");
		for (String str : s6)
			System.out.print(" " + str);

		String s7[] = s5.split("=");
		System.out.println("\nThe Output of split string ");
		for (String str : s7)
			System.out.print(" " + str); // It is Regular expression

		System.out.println("\nThe Contains of string T/F : " + s5.contains("Delhi")); // True
		System.out.println("\nThe Contains of string T/F : " + s5.contains("delhi")); // False

		String replace = s5.replace("New Delhi ", "Old Delhi");
		System.out.println("After replace " + replace);

		String s8 = "India is best country in the world ";
		System.out.println("Before trim of string length : " + s8.length());

		s8 = s8.trim();
		System.out.println("After trim of string length :" + s8.length());

	}

}
