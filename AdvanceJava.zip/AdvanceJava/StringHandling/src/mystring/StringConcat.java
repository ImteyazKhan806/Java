package mystring;

public class StringConcat {

	public static void main(String[] args) {
		System.out.println("\nString concataanation");

		System.out.println("Hello".length());

		String s1 = "Hello";
		String s2 = "Hello";

		System.out.println("s1 = " + s1 + "\ts2 = " + s2);
		String s3 = s1 + " Good Morning";

		System.out.println("s3 =" + s3);
		System.out.println("s1 =" + s1 + "\ts2 =" + s2);
		s1 = s2 + " Good morning";
		System.out.println("s1 = " + s1 + "\ts2 = " + s2);
		System.out.println("\ns1==s3  =" + (s1 == s3));
		
		String s4 = 10 + 20 + s1 + 11 + "Am" + "Java";
		System.out.println("s4 = " +s4);
		 
		//Concat method
		String s5 = s1.concat("\tJava").concat("\tBatch").concat(String.valueOf(11)).concat("\tAm").concat("\tWeek").concat("\tDays");
		 System.out.println("s5 = "+s5);

	}

}
