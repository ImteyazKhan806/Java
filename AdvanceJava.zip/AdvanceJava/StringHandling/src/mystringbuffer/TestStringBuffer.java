package mystringbuffer;

public class TestStringBuffer {

	public static void main(String[] args) {
		System.out.println("\nString Buffer method ......................");
		
		StringBuffer sb = new StringBuffer();
		System.out.println("The capacity of string  :" +sb.capacity());
		System.out.println("The length of string    :" +sb.length());
		System.out.println("sb is empty :"+sb);
		
		
		StringBuffer sb1 = new StringBuffer("Hello");
		System.out.println("The capacity of string : "+sb1.capacity());
		System.out.println("The length of string : "+sb1.length());
		System.out.println("sb1 = "+sb1);
		
		sb.append("abcde");
		System.out.println("sb  : "+sb);
		sb.append("123456");              //append method used to add the value 
		System.out.println("sb  = " +sb1) ;
		sb.append("lmnop");
		
		System.out.println("The capacity of string  :" +sb.capacity());
		System.out.println("The length of string    :" +sb.length());
		System.out.println("sb   :"+sb);
		
		sb.append("qrst"); //add  value
		System.out.println("The capacity of string  :" +sb.capacity()); //tab capacity double ho jata hai 34
		System.out.println("The length of string    :" +sb.length());
		System.out.println("sb  :"+sb);
		
		sb.trimToSize();
		System.out.println("After trimToSize method capacity of string :" +sb.capacity());
		System.out.println("The length of string : "+sb.length());
		
		sb.replace(5, 11, "fghijk");  //data replace
		System.out.println("sb :"+sb);
		
		sb.insert(11, "LMNOPQRST"); //data insert method
		System.out.println("sb :"+sb);
		
		sb.delete(11, 18);    //data delete method
		System.out.println("sb :"+sb);
		
		sb.reverse();     //data reverse method
		System.out.println("sb :"+sb);
		
		//new variable call
		StringBuffer sb2 = new StringBuffer("Good Morning");
		System.out.println("\nsb2 : "+sb2);
		
		sb2.setCharAt(5, 'm');  //letter change method   
		System.out.println("sb2 : "+sb2);
		
		String subS = sb.substring(7); //Used of Substring index num. start point se
		System.out.println("subS : "+subS);
		
		String subS1 = sb.substring(7, 11);   //Used of Substring index num. end point se  
		System.out.println("subS1 :"+subS1);
		
		
		
		
	
		
	}

}
