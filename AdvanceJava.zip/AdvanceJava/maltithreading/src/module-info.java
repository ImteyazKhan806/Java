/**
 * 
 */
/**
 * 
 */
module maltithreading {
}