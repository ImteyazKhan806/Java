package serialization_16;

import java.io.FileOutputStream;

import java.io.ObjectOutputStream;

public class MYServer {
 public static void main(String[] args) {
	System.out.println("\nSave the state of an object in file ");
	
	try {
		ObjectOutputStream write = new ObjectOutputStream(new FileOutputStream("star.txt"));
		Child c1 = new Child(10, 20, "java program", 30, 40);
		write.writeObject(c1);
		System.out.println("Object save ");
		
	} catch (Exception e) {
		e.printStackTrace();
	} 
	System.out.println("Ent of Main");
}
}
