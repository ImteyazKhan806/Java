package serialization_16;

import java.io.Serializable;

public class Child extends Base implements Serializable {
    
	int y;
	String str;
	static int z;
	transient int a;
	volatile int b;
	public Child(int x,int y, String str, int a, int b) {
		super();
		this.x= x;
		this.y = y;
		this.str = str;
		this.a = a;
		this.b = b;
	}
	
}
