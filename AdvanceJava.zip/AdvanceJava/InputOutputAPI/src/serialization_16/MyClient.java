package serialization_16;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class MyClient {
 public static void main(String[] args) {
	System.out.println("\nRead the object from file");
	
	try {
		ObjectInputStream reader = new ObjectInputStream(new FileInputStream("star.txt"));
		Child c1 = (Child)reader.readObject();
		System.out.println("Base class x "+c1.x);
		System.out.println("Child calss ............");
		System.out.println("Instance y "+c1.y);
		System.out.println("String str  "+c1.str);
		System.out.println("Static  z "+c1.z);
		System.out.println("Presient a "+c1.a);
		System.out.println("Volatile b "+c1.b);
		
	} catch (Exception e) {
		e.printStackTrace();
	}
}
}
