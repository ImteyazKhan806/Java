package serialization_16;

import java.io.Serializable;

public class Base implements Serializable 
{
   
	int x;

	
}
