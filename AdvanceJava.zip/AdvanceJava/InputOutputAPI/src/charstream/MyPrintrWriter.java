package charstream;

import java.io.*;


public class MyPrintrWriter {

	public static void main(String[] args)throws IOException {
		System.out.println("\nMyBufferWriter ");
		
		//Keyword Input generated
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		
		FileWriter fw= new FileWriter("Ducat1.txt");
	     PrintWriter pw = new PrintWriter(fw); 
		
		String s1 = " ";
		while(!s1.equalsIgnoreCase("stop")) {
			System.out.println("Enter any String :");
		    s1 = br.readLine();
		   
		pw.write(s1);
		pw.flush();
		}
		 System.out.println("Success.........");
	}

}
