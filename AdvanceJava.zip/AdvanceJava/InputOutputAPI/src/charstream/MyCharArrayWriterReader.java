package charstream;

import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MyCharArrayWriterReader {

	public static void main(String[] args)throws IOException {
		System.out.println("\nCharArrayWriter and Reader");
		CharArrayWriter wr = new CharArrayWriter();
		String s1 = "Java is Programming language";
		char[] ch = s1.toCharArray();
		for(int i =0; i <ch.length; i++)
			wr.write(ch[i]);
		    
		    System.out.println(wr.toString());
		    wr.writeTo(new FileWriter("xyz.txt"));
		    wr.flush();		    
		
		    //Read to the Buffer 
		    char[] ch1 = wr.toCharArray();
		    CharArrayReader fr = new CharArrayReader(ch1);
		    int ch2 =0;
		    while((ch2= fr.read()) != -1)
		    	System.out.print((char)ch2);
               
		    fr.close();
		    wr.close();
	}

}
