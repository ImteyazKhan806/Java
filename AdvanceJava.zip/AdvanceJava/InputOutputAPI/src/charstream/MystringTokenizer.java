package charstream;

import java.util.StringTokenizer;

public class MystringTokenizer {
public static void main(String[] args) {
	
	String s1 = "India = Delhi  : Nepal = Khatmandu  : Pakishtan = Ishlamabad ";
	
	StringTokenizer st = new StringTokenizer(s1, ":");
	System.out.println("Country\tCapital");
	while(st.hasMoreTokens()) {
		String s2 = (String) st.nextElement();
		System.out.println(s2);
	}

}
}
