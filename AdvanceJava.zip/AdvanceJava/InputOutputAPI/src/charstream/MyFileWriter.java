package charstream;

import java.io.FileWriter;
import java.io.IOException;

public class MyFileWriter {

	public static void main(String[] args) {
		
		System.out.println("FileWrite ..............");
		
		//create Object
		try {
			FileWriter fw = new FileWriter("abc.txt");
			String s1 = "Java is best programming language";
			char[] ch = s1.toCharArray();  //ctrl+1
			for(int i = 0; i < ch.length; i++) {
				fw.write(ch[i]);
				fw.flush(); //When the data is not collect then we use 
				
			}
			fw.close();
			System.out.println("Write is success ");
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
		

	}

}
