package charstream;

import java.io.FileReader;

public class MyFileReader {

	public static void main(String[] args) {
		System.out.println("\nFileReader..............");
		
		try {
			FileReader fr = new FileReader("abc.txt");
			int ch = 0;
			while((ch = fr.read()) != -1)
				System.out.print((char)ch);
			
			fr.close();
			System.out.println("\nRead in success");
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
	}

}
