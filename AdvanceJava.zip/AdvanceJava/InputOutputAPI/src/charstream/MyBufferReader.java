package charstream;

import java.io.*;


public class MyBufferReader {

	public static void main(String[] args)throws IOException {
		System.out.println("\nMyBufferWriter ");
		
		//File output generated
		FileReader fr = new FileReader("Ducat.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String s1 = " ";
		while((s1 = br.readLine()) != null) 
			System.out.println(s1);
		
		 System.out.println("File Output Success.........");
	}

}
