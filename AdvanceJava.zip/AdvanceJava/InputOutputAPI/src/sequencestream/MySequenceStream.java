package sequencestream;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.util.Enumeration;

public class MySequenceStream {

	public static void main(String[] args) {

		System.out.println("\nsequence Input stream ====");

		try {
			//SequenceInputStream sin = new SequenceInputStream(new FileInputStream("xyz.txt"),new FileInputStream("ducat.txt"));
			SequenceInputStream sin = new SequenceInputStream(new MyEnum());  //call to the Enumeration interface
			DataInputStream dis = new DataInputStream(sin);
			String s1 = " ";
			while ((s1 = dis.readLine()) != null) {
				System.out.println(s1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

class MyEnum implements Enumeration{
	InputStream in[];
	int i = 0;
	public MyEnum() throws IOException {
		
		in = new InputStream[] { new FileInputStream("abc.txt"), new FileInputStream("ducat.txt"),
				new FileInputStream("xyz.txt")}; // Here is multiple File Call
	}
	@Override
	public boolean hasMoreElements() { //check to true or false
		if(i < in.length)
			return true;
		else
		return false;
	}
	@Override
	public Object nextElement() {
		
		return in[i++];
	}
}
