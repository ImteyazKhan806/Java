package pipedio_16;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class MyPrintStream {

	public static void main(String[] args) throws IOException {
		
		PrintStream out = new PrintStream(new FileOutputStream("abc2.txt"));//FileNotFoundException create
		PrintStream out1 = new PrintStream(new FileOutputStream("abc3.txt"));
		
		System.setOut(out);
		System.setErr(out1);
		System.out.println("Hello Good Morning ");
		System.err.println("Bye Good Night");
		
	
	}

}
