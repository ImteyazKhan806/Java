package pipedio_16;

import java.io.IOException;
import java.io.PipedInputStream;

public class Pinput implements Runnable {

	PipedInputStream pInput;
	public Pinput(PipedInputStream pInput) {
		super();
		this.pInput = pInput;
	}
	@Override
	public void run() {
		
		int ch;
		System.out.println("Alphabatical\tASCII");
		for(int i = 1; i <= 26; i++) {
			try {
				ch = pInput.read();
				System.out.println((char)ch + " \t\t "+ch); //used typecasting char to ISCII
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}

}
