package pipedio_16;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class PipedInputOutput {

	public static void main(String[] args)throws IOException {
		PipedInputStream pInput = new PipedInputStream();
		PipedOutputStream pOut = new PipedOutputStream();
		pOut.connect(pInput);
		
		Poutput pOutput = new Poutput(pOut);
		Pinput pinput   = new Pinput(pInput);
		Thread t1 = new Thread(pOutput);
		Thread t2 = new Thread(pinput);
		t1.start();
		t2.start();
	}

}
