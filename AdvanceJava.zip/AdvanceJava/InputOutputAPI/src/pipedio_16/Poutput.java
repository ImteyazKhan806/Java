package pipedio_16;

import java.io.PipedOutputStream;

public class Poutput implements Runnable {

	
	PipedOutputStream pout;
	public Poutput(PipedOutputStream pout) {
		super();
		this.pout = pout;
	}
	@Override
	public void run() {
		for(int i=65; i<=90; i++) {
			try {
				pout.write(i);
				Thread.sleep(500);
			} 
			catch (Exception e) {
				
				e.printStackTrace();
			}
		}

	}

}
