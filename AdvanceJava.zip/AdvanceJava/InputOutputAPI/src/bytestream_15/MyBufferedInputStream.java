package bytestream_15;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;

public class MyBufferedInputStream {

	public static void main(String[] args) {
		System.out.println("\nBufferedInputStream ");
		
		try {
			FileInputStream fis = new FileInputStream("ducat1.txt");
			BufferedInputStream bis = new BufferedInputStream(fis);
			DataInputStream dis = new DataInputStream(bis);  // connected to the File 
			String s1 = " ";
			while((s1 = dis.readLine()) != null)
				System.out.println(s1);
			
		} catch (Exception e) {
		  e.printStackTrace();
		}
	}

}
