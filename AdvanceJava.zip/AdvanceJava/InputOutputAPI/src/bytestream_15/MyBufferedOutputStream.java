package bytestream_15;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

public class MyBufferedOutputStream {

	public static void main(String[] args) {
		System.out.println("BufferedOutputStream ");

		try {
			DataInputStream dis = new DataInputStream(System.in);
			FileOutputStream fos = new FileOutputStream("ducat1.txt");
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			DataOutputStream dos = new DataOutputStream(bos);

			String s1 = " ";
			while (!s1.equalsIgnoreCase("stop")) {
				System.out.println("Enter Any String :");
				s1 = dis.readLine();
				dos.writeBytes(s1);
				dos.flush();
			}
			dos.close();
			fos.close();
			dis.close();
			bos.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
