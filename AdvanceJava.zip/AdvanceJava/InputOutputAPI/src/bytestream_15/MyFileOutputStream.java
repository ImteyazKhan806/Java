package bytestream_15;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyFileOutputStream {

	public static 
	
	
	
	
	
	
	
	
	
	
	
	
	void main(String[] args) { // <- hum in exception (Throws ioException bhi handle kar sakte hai.

		System.out.println("\nWrite in File :");
		try {
			FileOutputStream fos = new FileOutputStream("abc.txt"); // // surrounded method se handle karte hai
			System.out.println("Create file success ");
			String s1 = "India is best country in the world.";
			byte[] b = s1.getBytes();

			for (int i = 0; i < b.length; i++)
				fos.write(b[i]); // IOException
			System.out.println("Write file in success ");
			fos.close(); // resources

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}

		System.out.println("End of Main");

	}

}
