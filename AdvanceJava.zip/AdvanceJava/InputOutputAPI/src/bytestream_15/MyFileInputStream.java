package bytestream_15;

import java.io.FileInputStream;


public class MyFileInputStream {

	public static void main(String[] args) {
		System.out.println("\nRead the txt file :");
		try {
			FileInputStream fis = new FileInputStream("abc.txt");
			System.out.println("The file is available :");
			
			int ch;
			while ((ch = fis.read()) != -1)
				System.out.print((char)ch);
			
				System.out.println("\nRead is success ");
				
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
          System.out.println("End if Main :");
	}

}
