package bytestream_15;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class MyDataOutputStream {

	public static void main(String[] args) {
		
		System.out.println("\n DataOutputStream, PrintStream ");
		try {
			
			DataInputStream dis = new DataInputStream(System.in);
			FileOutputStream fos = new FileOutputStream("ducat.txt");
			//DataOutputStream dos = new DataOutputStream(fos); //both used to here printSream or  dataOutputSream
			PrintStream ps = new PrintStream(fos);
			
			String s1 = " ";
			while(!s1.equalsIgnoreCase("stop")) {
			System.out.println("Enter any String :");
			s1 = dis.readLine();
			//dos.writeBytes(s1);
			//dos.writeChars(s1);   //used to char. by char. space 
			// dos.writeUTF(s1);      //used to some char. added ,unversal text format(UTF)		
			//dos.flush();  //buffer se free 
			
			
			ps.println(s1);
			ps.flush();
			
		}
		//dos.close();
		fos.close();
		dis.close();
		ps.close();
		
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
