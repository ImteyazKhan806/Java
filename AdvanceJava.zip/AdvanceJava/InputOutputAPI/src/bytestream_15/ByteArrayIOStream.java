package bytestream_15;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteArrayIOStream {

	public static void main(String[] args)throws IOException {
		System.out.println("\nByte Array Input Output Stream :");
		
		ByteArrayOutputStream wri = new ByteArrayOutputStream();
		String s1 = "Java is best programing language.";
		byte[] b = s1.getBytes();
		 
		for (int i = 0; i <b.length; i++)
			wri.write(b[i]);
		System.out.println(wri.toString());
		wri.writeTo(new FileOutputStream("xyz.txt"));
		System.out.println("Write in file success ");
		
		byte z[] = wri.toByteArray();
		ByteArrayInputStream fr = new ByteArrayInputStream(z);
		
		int ch = 0;
		while((ch = fr.read()) != -1)
			System.out.print((char)ch);
		System.out.println("\nRead the Success ");

	}

}
