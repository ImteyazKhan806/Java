package bytestream_15;


import java.io.FileOutputStream;
import java.io.IOException;

public class MyFileOutputStream1 {

	public static void main(String[] args) throws IOException { // <- hum in exception (Throws ioException bhi handle
																// kar sakte hai.

		System.out.println("\nWrite in File :");

		FileOutputStream fos = new FileOutputStream("C:\\xyz\\abc.txt",true);  //Write  to other file  Output
		System.out.println("Create file success ");
		String s1 = "India is best country in the world.";
		byte[] b = s1.getBytes();

		for (int i = 0; i < b.length; i++)
			fos.write(b[i]); // IOException
		System.out.println("Write file in success ");
		fos.close(); // resources

		System.out.println("End of Main");

	}

}
