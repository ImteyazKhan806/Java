package bytestream_15;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class MyDataInputStream {

	public static void main(String[] args) {
		System.out.println("\n DataInputStream ");
		
		try {
			FileInputStream fis = new FileInputStream("ducat.txt");
			DataInputStream dis = new DataInputStream(fis);  // connected to the File 
			String s1 = " ";
			while((s1 = dis.readLine()) != null)
				System.out.println(s1);
			
		} catch (Exception e) {
		  e.printStackTrace();
		}
	}

}
