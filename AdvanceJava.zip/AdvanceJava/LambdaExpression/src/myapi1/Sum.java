package myapi1;
@FunctionalInterface    //only one method called 
public interface Sum {
	
	int add(int a, int b);
//	int sub(int a, int b);

}
