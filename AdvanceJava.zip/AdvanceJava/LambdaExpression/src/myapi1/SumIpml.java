package myapi1;

public class SumIpml implements Sum {

	@Override
	public int add(int a, int b) {
		
		return (a+b);
	}



}
