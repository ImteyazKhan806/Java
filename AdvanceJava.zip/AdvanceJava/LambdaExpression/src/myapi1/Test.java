package myapi1;

public class Test {
 public static void main(String[] args) {
	System.out.println("\nThe interface method can be used Lambda Expression only one method : ");
	
	Sum obj1 = (a, b) -> {
		System.out.println("Lambda Expression :");
		return (a+b);
	};
	System.out.println("Add = " +obj1.add(400,200));
	 
	  Sum obj2 = new Sum() {
		
		@Override
		public int add(int a, int b) {
			
			return a+b;
		}
	};
	Runnable r1 = new Runnable() {
		
		@Override
		public void run() {
		     System.out.println(" anonymous class :"+Thread.currentThread().getName());
		     
		}
	};
	Thread t1 = new Thread(r1);
	t1.start();
	System.out.println("Add = "+obj2.add(1000, 200));
	
	Runnable r2 = ()->System.out.println("Lambda Exp. class "+Thread.currentThread().getName());
	Thread t2 = new Thread(r2);
	t2.start();
}
}
 //Lambda expression not Extra class generated.
  //Implemention is generated to the Extra one class. 