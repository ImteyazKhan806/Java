package myapi;

public class SumIpml implements Sum {

	@Override
	public int add(int a, int b) {
		
		return (a+b);
	}

	@Override
	public int sub(int a, int b) {
	
		return (a-b);
	}

}
