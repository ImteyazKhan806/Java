package myapi;

public class Test {
 public static void main(String[] args) {
	 System.out.println("\nThe interface method can be used impl classes :");
	 Sum obj = new SumIpml();
	 System.out.println("Add =  " +obj.add(200, 100));
	 System.out.println("Sub =   " +obj.sub(300, 100));
	 
	 System.out.println("\nThe interface method can be used Annonymous class : ");
	   Sum obj1 = new Sum() {
		
		@Override
		public int sub(int a, int b) {
			
			return (a-b);
		}
		
		@Override
		public int add(int a, int b) {
		
			return (a+b);
		}
	};
	
	System.out.println("Add = " +obj1.add(300, 400));
	System.out.println("Sub = " +obj1.sub(500, 300));
	
	 
}
}
