package lmbdaexp;
@FunctionalInterface    //only one method called 
public interface Sum {
	
	int add(int a, int b);


}
