package lmbdaexp;

public interface MyMessage {
    String hellosay(String msg); 
}
