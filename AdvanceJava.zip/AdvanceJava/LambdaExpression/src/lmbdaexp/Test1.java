package lmbdaexp;

public class Test1 {

	public static void main(String[] args) {
		System.out.println("\nCharacteristics of a lambda expression :");

		// With type with parenthesis with return with curly braces
		Sum obj = (int x, int y) -> {
			return (x + y);
		};
		System.out.println("Add = " + obj.add(500, 100));

		// without type with parenthesis with return type with curly braces
		Sum obj1 = (x, y) -> {
			return x + y;
		};
		System.out.println("Add = " + obj1.add(50, 50));

		// without type parenthesis without return type without curly braces
		Sum obj2 = (x, y) -> (x + y);
		System.out.println("Add = " + obj2.add(60, 60));
		
		//without type without parenthesis without return type without curly braces
		MyMessage m = S->S+"Good Morning";
		System.out.println("msg : "+m.hellosay("Hello "));
	}

}
