
module Reflection {
	requires java.desktop;
}