package p1;

import java.awt.Frame;

public class SimpleClassName {
 
	
	 public static void printClassName(Object ob) {
		 Class c1 = ob.getClass();
		 System.out.println("The name of class : "+c1.getName());
	 }
	public static void main(String[] args) {
		System.out.println("\nGet the Name of Class :");
		 SimpleClassName obj = new SimpleClassName();
		 printClassName(obj);
		 
		 Thread t1 = new Thread();
		 printClassName(t1);
		 
		 Frame f = new Frame();
		 printClassName(f);

	}

}
