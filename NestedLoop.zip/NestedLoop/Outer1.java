//package p1.staticnested;
// can main kept static nested class 
class Outer1{
 int x = 10;
 static int y = 20;
 static void display(){
  System.out.println("Display method of Outer class ");
  System.out.println("y = "+y);
 }
 static class Inner1{
	 int a = 30;
	 static int b = 40;
	 void show(){
		System.out.println("\nshow method of Inner class ");
      //  System.out.println("Instance x = "+x);
        System.out.println(" static y = "+y);
        System.out.println("a = "+a); 
        System.out.println("b = "+b); 
        display();
	 }
	 static void out(){
		 System.out.println("\nout method of Inner class ");	 
 }
}
public static void main(String...s){
	System.out.println("\nmain method of outer class ");
	System.out.println("static outer y = "+y);
	display ();
	Inner1 i = new Inner1();
	  i.show();
	  out();
	  System.out.println("b = "+b);
}
}