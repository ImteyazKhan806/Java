package p4.sub1.sub2;

class GreatGrandFather{
          int x = 5;
}
class GrandFather extends GreatGrandFather{
	     int x = 10;
}
class Father extends GrandFather{
        int x = 20;
}
class Child extends Father{
    int x = 30;
	void show(){
	System.out.println("Local class x ="+x);
	System.out.println("Child  class x ="+this.x);
	System.out.println("Father class x ="+super.x);
	System.out.println("Father class x = "+((Father)this).x);
	System.out.println("GrandFather class x ="+((GrandFather)this).x);
	System.out.println("GreatGrandFather class x ="+((GreatGrandFather)this).x);
	
	}	
}
class Multilevel1{
   public static void main(String...s){
	   Child c1 =new Child();
	   c1.show();
	   System.out.println("Main...............");
	   System.out.println("Child class x = "+c1.x);
	   System.out.println("Father class x ="+((Father)c1).x);
	   System.out.println("GrandFather class x ="+((GrandFather)c1).x);
	   System.out.println("GreatGrandFather class x ="+((GreatGrandFather)c1).x);
	   
   }
}