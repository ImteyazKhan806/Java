/*
  Implementation Inheritance => All Data member & member function of
  parent class are part of the child class object if they are not private. 
*/

class Base {
     int x;
	 int y;
	 void show(){
	 System.out.println("Show Method of Base class :");
     System.out.println("x = " +x);
     System.out.println("y = " +y);
}	 
}
 class Child extends Base{
     void getData(int x ,int y){
	 System.out.println("getData method of child class :");
	 this.x = x;
	 this.y = y;
}
}
class Test{
       public static void main(String...s){
       
       Base b1= new Base();
       b1.show();
	  // b1.getData(10,20);  //Can't part of parent class
	   Child c1 = new Child();
	   c1.show();
	   c1.getData(10,20);
	   c1.show();
       	   
 }
}	   

