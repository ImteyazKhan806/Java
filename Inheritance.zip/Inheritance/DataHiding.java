/*
  DataHiding =>Whenever parent class & child class having 
  same member.
  Then this concept is known as DataHiding.
  ==>The DataHiding problem solve with help of super keyword.
*/

 package p1;

class Base{
     int x =10;
}
class Child extends Base{
    int x = 20;
	void show(int x){
	System.out.println("Local  class x =" +x);
	System.out.println("Child  class x =" +this.x);
	System.out.println("Base   class  x  =" +super.x);
	
	}
}
class DataHiding{
    public static void main(String...s){
	Child c1 = new Child();
	c1.show(30);
}
}
/*
 Q.1 How super call the parent class Data Mamber ?
 
 Ans==>The super is part of child class object which memory space used by the 
       parent class Data Member that particular reference Id kept in super 
	   and all the properties & behaviour of parent class is part of child class object.
	   
	   ==>The Reference id of super keyword can't see  because its part of child object.
	   ==>The super & this keyword not used in static method.
	   
	   c:\javabatch11AM>javac -d . DataHiding.java
	   
	   c:\javabatch11AM>java p1.DataHiding

*/