package p3.sub1.sub2;
class Base{
     int x =30;
}
class Child extends Base{
    int x= 20;
	void show(int x){
	System.out.println("Local var x =" +x);
	System.out.println("child var x =" +this.x);
	System.out.println("Base var x  ="+super.x);
	
	}
}
class DataHiding1{
    public static void main(String...s){
	Child c1 = new Child();
	c1.show(10);
}
}