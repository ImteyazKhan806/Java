package p2.sub1.sub2;
class GrandFather{
     int x =10;
}
class Father extends GrandFather{
     int x =20;
}
class Child extends Father{
    int x = 30;
	void show(){
	System.out.println("child class x =" +x);
	System.out.println("child class x ="+this.x);
	System.out.println("Father class x  ="+super.x);
	System.out.println("Father class x ="+((Father)this).x);
	System.out.println("GrandFather class x  ="+((GrandFather)this).x);
	
	}
}
 class Multilevel{
    public static void main(String...s){
	Child c1 = new Child();
	c1.show();
	System.out.println("Main ......................");
	System.out.println("Father class x  ="+c1.x);
	System.out.println("Father class x ="+((Father)c1).x);
	System.out.println("GrandFather class x  ="+((GrandFather)c1).x);
}
}